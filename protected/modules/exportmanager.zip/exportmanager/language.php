<?php
/*Add this new words to your current language file*/
/** Export Modules Translation*/
$lang['Export Merchant']='';
$lang['Import Merchant']='';
$lang['Admin Panel']='';
$lang['Filter merchant']='';
$lang['All Merchant']='';
$lang['Merchant Name']='';
$lang['Filter is required']='';
$lang['Merchant is required']='';
$lang['Filter options']='';
$lang['Include Food item']='';
$lang['No records found']='';
$lang['Something went wrong']='';
$lang['Merchant successfully replicated']='';
$lang['Address']='';
$lang['New Email address']='';
$lang['New Username']='';
$lang['New Password']='';
$lang['Error has occured cannot create upload directory']='';
$lang['File has no content']='';
$lang['Error: something went wrong during processing your request']='';
$lang['File successfully imported']='';
$lang['Admin Merchant List']='';

